import 'package:flutter/material.dart';

class Telalistalocais extends StatelessWidget {
  const Telalistalocais({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    throw UnimplementedError();
  }
}
